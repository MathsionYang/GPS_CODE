﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Collections;

namespace 导线测量
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("a为坐标正算,b为坐标反算");
            Console.WriteLine("c为方位角的推算,d为角度闭合差");
            Console.WriteLine("e为坐标增量闭合差");
            Console.WriteLine("【1】输入计算类型a或b,c,d,e");
            ArrayList _distance = new ArrayList();
            char s = Convert.ToChar(Console.ReadLine());
           switch(s)
            {
                case'a'://坐标正算
            Console.WriteLine("【2】请输入已知点坐标：");
           double X0 = Convert.ToInt32(Console.ReadLine());
           double Y0 = Convert.ToInt32(Console.ReadLine());
           Console.WriteLine("【3】请输入距离和角度：");
                double L=Convert.ToInt32(Console .ReadLine());
                double a=Convert.ToInt32(Console .ReadLine());
            double a1=a*Math.PI/180;
            double X1=X0 + L * Math.Cos(a1);
            double Y1 = Y0 + L * Math.Sin(a1);
            Console.WriteLine("未知点X1={0}:",X1 );
            Console.WriteLine("未知点Y1={0}:", Y1);
            Console.ReadLine();
                break;//坐标正算 
                case 'b'://坐标反算
            Console.WriteLine("请输入已知点坐标1");
            double x1 = Convert.ToInt32(Console.ReadLine());
            double y1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("请输入已知点坐标2");
            double x2 = Convert.ToInt32(Console.ReadLine());
            double y2 = Convert.ToInt32(Console.ReadLine());
            double _x = (x1 - x2);
            double _y = (y1 - y2);
            double angle = Math.Atan(_y / _x);
            if (_x > 0 && angle < 0)//_x＞０,angle为负号时,angle应加360,当_x<0时，应给angle加180

            {
                angle += 360;
                }
            else if (_x < 0)
              {
                  angle += 180;
            }
             
            double l = _x / (Math.Cos(angle));
            Console.WriteLine("方位角{0}", angle);
            Console.WriteLine("两点距离{0}", l);
          
            Console.ReadLine();
            break;//坐标反算
                case 'c': //方位角的推算
            Console.WriteLine("输入后方位角");
            double angle1 = Convert.ToInt32(Console.ReadLine());
                if (angle1 > 180)
                 {
                   angle1 -= 180;
                  }
                  else  angle1 += 180;
            double ang=0;;    
            Console.WriteLine("输入转折角左1或右2");
            int   num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("输入转折角");
            double angle01 = Convert.ToInt32(Console.ReadLine());
            if (num==1)

            {
                 ang = angle1 + angle01;

            }
            else  ang=angle1-angle01;

            Console.WriteLine("输出后方位角={0}",ang);
            Console.ReadLine();
            break;//方位角的推算
                case 'd'://角度闭合差
            Console.WriteLine("输入转折角个数n");
            double m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("输入转折角");
            double      size = Convert.ToInt32(Console.ReadLine());
            double i =1;

       
            double _f=0;
            double _f1 = 0;
            
            while (i < m)
            {
                Console.WriteLine("输入转折角");
                size = Convert.ToInt32(Console.ReadLine());
                size += size;
                i++;

               _f = size - ((m - 2) * 180);
             

            }
                Console.WriteLine("角度闭合差={0}", _f);
                _f1 = _f / m;
                Console.WriteLine("角度改正数={0}", _f1);
                Console.ReadLine();

                break;//角度闭合差
               case'e':
                Console.WriteLine("输入起始已知点坐标A0");
               double Xa0 = Convert.ToInt32(Console .ReadLine());
               double Ya0 = Convert.ToInt32(Console.ReadLine());
               Console.WriteLine("输入终止点B0");
               double Xz0 = Convert.ToInt32(Console.ReadLine());
               double Yz0 = Convert.ToInt32(Console.ReadLine());
               double Xaa = 0;//x轴坐标增量
               double Yaa = 0;//y轴坐标增量
               double Dis0 = 0;

                Console.WriteLine("输入要计算的导线点总数Nums:");
                double Nums = Convert.ToInt32(Console.ReadLine());
                //int[] _dis = new int[(int)Nums];

                for (i = 0; i < Nums; i++)

                {
                    Console.WriteLine("输入边的方位角：@0");
                    double angleAZ0 = Convert.ToInt32(Console.ReadLine());
                    double angleAZ = angleAZ0 * Math.PI / 180;
                  
                        Console.WriteLine("输入边长Dis:");
                        double Dis = Convert.ToInt32(Console.ReadLine());
                        _distance.Add(Dis);
                     
                    
                    Dis0 += Dis;
                    Xaa +=  Dis * Math.Cos(angleAZ);
                    Yaa += Dis * Math.Sin(angleAZ);


                }
                double Fx0 = 0;double Fy0=0;double Fs=0;
                Fx0 = Xa0 + Xaa - Xz0;
                Fy0 = Ya0 + Yaa - Yz0;
                Fs = Math.Sqrt((Fx0 * Fx0) + (Fy0 * Fy0));
                double K1 = Fs / Dis0;
                Console.WriteLine("输出精度K={0}", K1);
                for (int t = 0; t < _distance.Count; t++)
                {
                   double distance = (double)_distance[t];
                    double V = ((2 - 3) * K1) * distance;
                    Console.WriteLine("坐标增量改正数={0}",V);
                }


                    Console.ReadLine();
              
 break;
                  






                   

            
                 
           

              



          
              
        }

        }
    }
    
}
